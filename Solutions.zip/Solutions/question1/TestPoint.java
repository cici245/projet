
package question1;
class Point {
	private double x ; // abscisse
	private double y ; // ordonnee

  	Point(double abs, double ord) {
		x = abs; y = ord;
	} 

  	public void affiche (){ 
    	System.out.println ("Coordonnees " + x + " " + y) ; 
  	}

  	public static Point maxNorme (Point p1, Point p2){
  		double n1 = p1.x * p1.x + p1.y * p1.y;
  		double n2 = p2.x * p2.x + p2.y * p2.y;
  		if (n1 > n2) return p1;
  		else return p2;
  	}

  	public Point maxNorme(Point autreP){
  		double d = x * x + y * y;
  		double autreD = autreP.x * autreP.x + autreP.y * autreP.y;
  		if (d > autreD) return this;
  		else return autreP;
  	}
} 

public class TestPoint {
	public static void main(String[] args) {
		Point p1 = new Point (2, 5) ; System.out.print ("p1 : ") ; p1.affiche() ;
		Point p2 = new Point (3, 1) ; System.out.print ("p2 : ") ; p2.affiche() ; 
		Point p = Point.maxNorme (p1, p2) ;
		System.out.print ("Max de p1 et p2 : ") ; p.affiche() ;

		p = p1.maxNorme (p2) ; // ou p2.maxNorme(p1)
		System.out.print ("Max de p1 et p2 : ") ; p.affiche() ;
	}
}