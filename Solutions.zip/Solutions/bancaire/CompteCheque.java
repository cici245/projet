package bancaire;

import java.util.Objects;

public class CompteCheque extends Compte {
	private double coutTransaction;
	private int nbTransac = 0;

	CompteCheque(Client c, double s, double ct) {
		super(c, s); // appel du constructeur parent
		coutTransaction = ct;
	}
	
	@Override
	public void depot(double m){
		nbTransac++;
		super.depot(m);
	}
	@Override
	public double retrait(double m){
		nbTransac++;
		return super.retrait(m);
	}

	public double calculCoutTransac() {
		double cout = nbTransac * coutTransaction;
		retrait(cout);
		nbTransac = 0;
		return cout;
	}
	@Override
	public String toString() {
		return super.toString() + "[cout par transaction: " + coutTransaction + "]";
	}
	@Override
	public boolean equals(Object autreObj) {
		if (!super.equals(autreObj)) return false;
		CompteCheque autreCC = (CompteCheque) autreObj;
		return coutTransaction == autreCC.coutTransaction;
	}
	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), coutTransaction); 
	}
}
