package bancaire;

public class CompteTest {

	public static void main(String[] args) {
		// Test la classe Compte
		
		// on se crée deux clients
		Client client1 = new Client ("Alfred", 65);
		Client client2 = new Client ("Germaine", 58);
		
		// On  crée un compte pour Alfred avec 1000 $
		Compte compteAlfred  = new Compte(client1, 1000);
		infoCompte("Création du compte pour Alfred",compteAlfred);
		// On  crée un compte pour Germaine avec 5000 $
		Compte compteGermaine  = new Compte(client2, 5000);
		infoCompte("Création du compte pour Germaine", compteGermaine);
		
		// opérations bancaires
		compteAlfred.retrait(500);
		infoCompte("Retrait de 500", compteAlfred);
		
		compteAlfred.depot(1000);
		infoCompte("Dépot de 1000", compteAlfred);
		
		compteGermaine.transfert(compteAlfred, 1000);
		infoCompte("Transfert de 1000 du compte de Germaine vers celui d'alfred",compteAlfred);
		infoCompte("",compteGermaine);
		
		compteGermaine.transfert(compteAlfred, 5000);
		infoCompte("Tentative de transfert de 5000 du compte de Germaine vers celui d'alfred",compteAlfred);
		infoCompte("",compteGermaine);
		
		// test champs statiques
		System.out.println("Banque = " + Compte.BANQUE);
		System.out.println("Nombre de comptes créés: "+Compte.getNbComptes());
		System.out.println("Nombre de clients créés: "+Client.getNbClients());
		
		// test méthode toString
		System.out.println(client1.toString());
		System.out.println(compteAlfred.toString());
		
		// test d'un compte épargne
		Client client3 = new Client("Alberto", 35);
		CompteEpargne compteAlberto = new CompteEpargne(client3, 10500, 5);
		System.out.println("Nombre de comptes créés: "+CompteEpargne.getNbComptes());
		System.out.println(compteAlberto.toString());
		compteAlberto.calculInteret();
		System.out.println(compteAlberto.toString());
		
		// test compteCheque
		CompteCheque ch1 = new CompteCheque(client3, 1000, 0.5);
		System.out.println(ch1);
		ch1.retrait(100);
		ch1.retrait(100);
		ch1.depot(50);
		System.out.println(ch1);
		ch1.transfert(compteAlfred, 150);
		System.out.println("Après transfert de 150 à Alfred");
		System.out.println(ch1);
		System.out.println(compteAlfred);
		System.out.println("Coût des transaction: " + ch1.calculCoutTransac());
		System.out.println(ch1);
		System.out.println("Coût des transaction: (doit être de zéro!):  " + ch1.calculCoutTransac());
		
		// test polymorphisme
		Compte[] listeComptes = {compteAlberto, ch1, new CompteEpargne(client2, 5000,6), 
								new CompteCheque(client2, 2000, 0.5), 
								new CompteEpargne(client1, 3000, 5)};
		
		System.out.println("\nTest de polymorphisme\n");
		for (Compte c : listeComptes)
			System.out.println(c);
				
		// test equals
		if (compteAlberto.equals(ch1)) System.out.println("test1 est vrai");
		else System.out.println("Test1 est faux");
		if (listeComptes[0].equals(listeComptes[2])) System.out.println("test2 est vrai");
		else System.out.println("Test2 est faux");
		if (compteAlberto.equals(new CompteEpargne(client3, 11025.0, 5))) System.out.println("test3 est vrai");
		else System.out.println("Test3 est faux");
		
		// test compteMaxSolde
		System.out.println(Compte.compteMaxSolde(listeComptes));
		System.out.println(Compte.compteMaxSolde(listeComptes[4], compteAlfred, compteGermaine));
		
	}
	
	public static void infoCompte(String message, Compte c) {
		System.out.printf("%s\nClient: %s, solde: %.2f\n", message, c.getClient().getNom(), c.getSolde());
	}
}
