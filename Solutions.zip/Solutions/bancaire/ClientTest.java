package bancaire;

import java.util.ArrayList;

public class ClientTest {
	public static void main(String[] args) {
		// Test la classe Client
		Client c = new Client("François", 35);
		System.out.printf("Client: %s, âge = %d\n", c.getNom(), c.getAge());
		
		// test ArrayList
		ArrayList<Client> listeCLients = new ArrayList<Client>();
		listeCLients.add(c);
		listeCLients.add(new Client("Bernie", 25));
		listeCLients.add(new Client("Julia", 28));
		listeCLients.add(new Client("Rick", 55));
		System.out.println(listeCLients);

		//remplacement
		listeCLients.remove(1); //supprime Bernie
		System.out.println(listeCLients);
		listeCLients.set(2, new Client("Fredie", 33)); 		//remplacement
		System.out.println(listeCLients);
		listeCLients.add(1, new Client("Thérèsa", 101));
		System.out.println(listeCLients);
		for (Client cl : listeCLients) System.out.println(cl);
	}
}