package bancaire;

import java.util.Objects;

/**
 * Un objet <code>Compte</code> represente un compte bancaire et permet des transactions.
 * Le possesseur du compte est un objet <code>Client</code>
 * @see Client
 * @author François Audet
 *
 */
public class Compte {
	/**
	 * Caisse Desjardins
	 */
	public static final String BANQUE = "Caisses Desjardins";
	private Client client;
	private double solde;
	private static int nbComptes = 0;
	/**
	 * 
	 * @param c <code>Client</code> qui possède le compte.
	 * @param s Solde initial au compte
	 * 
	 */
	public Compte(Client c, double s) {
		client = c;
		solde = s;
		nbComptes++; // compte le nombre d'objets Compte créés
	}
	public Compte(Client c) { // constructeur à un seul argument
		this(c, 0);
	}
	
	public double getSolde() {
		return solde;
	}
	
	public Client getClient() {
		return client.clone();
	}
	
	public void depot(double m){
		solde += m;
	}
	/**
	 * Retire le montant spécifié comme argument, si le solde le permet,
	 * sinon met le compte à zero.
	 * @param m le montant à retirer
	 * @return le montant effectivement retiré du compte
	 */
	public double retrait(double m) {
		if (m > solde) {
			double retraitEffectif = solde;
			solde = 0;
			return retraitEffectif;	
		}
		else {
			solde -= m;
			return m;
		}
	}
	
	public void transfert(Compte autreCompte, double montant) {
		double retraitEffectif = retrait(montant); // si possible, retire montant de ce compte
		autreCompte.depot(retraitEffectif); // dépose le montant réel retiré dans l'autre compte
	}
	public String toString() {
		return getClass().getName() + "[client: " + client.toString() + " solde: " + solde + "]";
	}
	/**
	 * méthode statique qui retourne le nombre d'objets Compte créés
	 * @return nombre d'instances <code>Compte</code> qui ont été créées
	 */
	public static int getNbComptes(){
		return nbComptes;
	}
	@Override
	public boolean equals(Object autreObj) {
		if (this == autreObj) return true;
		if (autreObj == null) return false;
		if (getClass() != autreObj.getClass()) return false;
		Compte autreCompte = (Compte) autreObj;
		return client.equals(autreCompte.client) && solde == autreCompte.solde;
	}
	@Override
	public int hashCode() {
		return Objects.hash(client, solde);
	}
	public static Compte compteMaxSolde(Compte ...comptes) {
		double maxSolde = 0;
		Compte maxCompte = null;
		for (Compte c : comptes) {
			if (c.solde > maxSolde) {
				maxSolde = c.solde;
				maxCompte = c;
			}
		}
		return maxCompte;
	}
}