package bancaire;

import java.util.Objects;

public class CompteEpargne extends Compte {
	
	private double tauxInteret;
	
	public CompteEpargne(Client c, double s, double t){
		super(c,s); // appel du constructeur parent
		tauxInteret = t;
	}
	
	public double calculInteret() {
		double interets = getSolde() * tauxInteret / 100;
		depot(interets);
		return interets;
	}
	public String toString() {
		return super.toString() + "[taux d'intérêt: " + tauxInteret + "]";
	}
	@Override
	public boolean equals(Object autreObj) {
		if (!super.equals(autreObj)) return false;
		CompteEpargne autreCE = (CompteEpargne) autreObj;
		return tauxInteret == autreCE.tauxInteret;
	}
	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), tauxInteret);
	}
}
