package bancaire;

/**
 * Un <code>Client</code> est un objet qui représente
 * le possesseur d'un objet <code>Compte</code>.
 * @see Compte
 * @author François Audet
 */
public class Client {
	private String nom;
	private int age;
	private static int nbClients = 0;
	
	/** Constructeur de la classe <code>Client</code>
	 * 
	 * @param n le nom du client
	 * @param a l'âge du client
	 */
	public Client(String n, int a) {
		nom = n;
		age = a;
		nbClients++; // compte le nombre de clients créés
	}
	
	public Client(String n) { // constructeur à un seul argument
		this(n, 18);
	}
	
	// constructeur privé utilisé uniquement par la méthode clone()
	// afin de ne pas incrémenter le compteur nbClients
	private Client(String n, int a, boolean byPass){
			nom = n;
			age = a;
	}
	/**
	 * 
	 * @return le nom du client
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * 	
	 * @return l'âge du client
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @return une copie du client
	 */
	public Client clone() {
		return new Client(this.nom, this.age, true);
	}
	public String toString() {
		
			return getClass().getName() + "[nom: " + nom + "  Âge: " + age + "]";
	}
	public static int getNbClients(){
		return nbClients;
	}
	@Override
	public boolean equals(Object autreObj) {
		if (this == autreObj) return true;
		if (autreObj == null) return false;
		if (getClass() != autreObj.getClass()) return false;
		Client autreClient = (Client) autreObj;
		return nom.equals(autreClient.nom) && age == autreClient.age;
	}
}
