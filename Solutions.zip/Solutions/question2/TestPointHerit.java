package question2;

class Point {
	private double x ; // abscisse
	private double y ; // ordonnee

  	Point(int abs,int ord) {x=abs; y=ord;} 


	public void affCoord(){ 
    	System.out.println ("Coordonnées : " + x + " " + y) ; 
    }
}

class PointNom extends Point { 
	private String nom ; 

	public PointNom (int x, int y, String nom) { 
		super (x, y); 
		this.nom = nom;
	}

	public void affCoord(){ 
		System.out.print ("Point de nom " + nom + " ");
		super.affCoord();
	}
}

 

public class TestPointHerit {
	public static void main(String[] args) {
		Point p = new Point(3, 4);
		PointNom pn1 = new PointNom(1, 7, "A") ; 
		pn1.affCoord() ; // methode de PointNom 
		PointNom pn2 = new PointNom(4, 3, "B") ;
		pn2.affCoord() ; // méthode de PointNom
		p.affCoord();// méthode de Point
	}
}