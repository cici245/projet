const express = require('express');
const app = express();
const fs= require('fs');
const bodyParser=require('body-parser');

app.use(bodyParser.json());
app.use(express.static('Mail2'));

app.post('/addLetters', function(req, res) {
  console.log(req.body);
  fs.writeFile('package.json', JSON.stringify(req.body));

  res.send('saved!');
});


app.get('/getLetters', function(req, res) {
  res.sendFile(__dirname+"/package.json");
  /*let data = fs.readFile('package.json');
  res.send(data);*/
});

app.listen(3000, function() {
  console.log('Server is listening on port 3000...');
});