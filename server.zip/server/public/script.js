$('#envoi').click(function() {
  var msg={destinataire:$('#dest').val(), subject:$('#subjt').val()};
   $.ajax({
      url: '/addLetters',
      type: 'POST',
      data:JSON.stringify(msg),
      contentType:'application/json',
      success: function(response) {
        console.log(response);
      },
    });
   
})
    

$('#retreive').click(function() {
    $.ajax({
      url: '/getLetters',
      type: 'GET',
      contentType: 'application/json',
      success: function(response) {
        console.log(response);
        document.querySelector('#container').innerHTML = JSON.stringify(response);
        //$('#container'). = response;
      },
    })});


    /*fetch('/addLetters',{
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body:JSON.stringify(msg),
    })
    .then(response => response.text())
    .then(response => console.log(response));*/
   