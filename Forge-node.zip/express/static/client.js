const keyPair = forge.pki.rsa.generateKeyPair({ bits: 2048, e: 0x10001 });


 $(document).ready(function() {
$('#envoi').click(function() {
    
   
  const msg={destinataire:$('#dest').val(), subject:$('#subjt').val()};
   $.ajax({
      url: '/addLetters',
      type: 'POST',
      data:JSON.stringify(msg),
      contentType:'application/json',
      success: function(res) {
        console.log(res);
      },
    });})

$('#retreive').click(function() {
    $.ajax({
      url: '/getLetters',
      type: 'GET',
      contentType: 'application/json',
      success: function(data) {
      
        $('#container').html(data);
      },
    })});});


   
   


// Fonction pour chiffrer le texte
function encrypt() {

    const texte = document.getElementById('msg').value;
     var encrypted = forge.util.encode64(keyPair.publicKey.encrypt(forge.util.encodeUtf8(texte)));
    document.querySelector('.result').innerText=encrypted;
  
}

// Fonction pour déchiffrer le texte
function decrypt() {
    
    const textEnc = document.querySelector('.result').innerText;
    var decrypted = forge.util.decodeUtf8(keyPair.privateKey.decrypt(forge.util.decode64(textEnc)));
    document.querySelector('.result').innerText = decrypted;
}
