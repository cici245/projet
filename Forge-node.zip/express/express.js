const exp = require('express');
const appli = exp();



appli.use(exp.static('static'));

appli.listen(8080, function() {
  console.log('Server is listening on port 3000...');
});

// const app = express();
// const fs= require('fs');
// const bodyParser=require('body-parser');

// app.use(bodyParser.json());
// app.use(express.static('public'));

// app.post('/addLetters', function(req, res) {

//   fs.writeFileSync('package.json', JSON.stringify(req.body));

//   res.send('saved!');
// });


// app.get('/getLetters', function(req, res) {
//   let data = JSON.parse(fs.readFileSync('package.json'));
//   res.send(data);
// });

// app.listen(3000, function() {
//   console.log('Server is listening on port 3000...');
// });